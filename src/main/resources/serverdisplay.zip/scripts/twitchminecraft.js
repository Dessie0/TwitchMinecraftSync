
//Please do not touch this function!
function update_header(text) {
    if(text === "") {
        getTwitchResponse()
    } else {
		getMinecraftHead(text.uuid);
		getTwitchLogo(text.logoURL);
		
		//Hide the loading message
		document.getElementById("js-loader").hidden = true;
		
		//Show the x between the images.
		document.getElementById("x-icon").hidden = false;
		
        switch(text.response_type) {
            case "CLAIMED": document.getElementById("js-subheader").innerHTML = `Successfully linked ${text.player_name} to ${text.channel} at Tier ${text.tier}`; break;
			case "RESUBBED": document.getElementById("js-subheader").innerHTML = `Successfully re-linked ${text.player_name} to ${text.channel} at Tier ${text.tier}`; break;
            case "ALREADY_CLAIMED": document.getElementById("js-subheader").innerHTML = `You've already claimed your Twitch rewards! (${text.channel}: Tier ${text.tier}) Expires ${text.expires}`; break;
            case "ACCOUNT_USED": document.getElementById("js-subheader").innerHTML = `The Twitch account ${text.channel} is already in use by the user ${text.player_name}!`; break;
            case "NOT_SUBBED": document.getElementById("js-subheader").innerHTML = `The Twitch account ${text.channel} is not currently subscribed!`; break;
			case "FAILED": { 
				document.getElementById("js-subheader").innerHTML = `An error occurred. Usually this happens if the link you used has expired, or already been used. Please try again with a new link.`;
				document.getElementById("x-icon").hidden = true;
				break;
			}
        }
    }
}

//Please do not touch this function!
function getTwitchResponse() {
    var xmlHttp = new XMLHttpRequest();

    xmlHttp.onreadystatechange = function() {
        if(this.readyState === 4 && this.status === 200) {
            var json = JSON.parse(xmlHttp.responseText)

            if(json.response_type === "WAITING") {
				//Attempt again in 1 second.
                setTimeout(getTwitchResponse, 1000);
            } else {
                update_header(json)
            }
        }
    }

    xmlHttp.open("GET", "/twitchresponse?code=" + new URLSearchParams(window.location.search).get("code"), true);
    xmlHttp.send();
}

function getMinecraftHead(uuid) {
	document.getElementById("minecraft_head").src = "https://crafatar.com/avatars/" + uuid + "?overlay&size=200";
}

function getTwitchLogo(url) {
	document.getElementById("twitch_logo").src = url;
}
